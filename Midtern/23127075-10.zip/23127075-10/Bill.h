#ifndef _BILL_H_
#define _BILL_H_

#include "Product.h"
#include <vector>

class Bill
{
private:
    bool hasVAT; // 0 - hoa don ban le, 1 - hoa don gia tri gia tang
    int VAT;
    string id;
    string clientName;
    vector<Product> products;

public:
    Bill();
    ~Bill();

    void input();
    void output();

    bool checkVAT(); // Check don gia tri gia tang
    string getClientName();
    double getTotalPrice();
};



#endif