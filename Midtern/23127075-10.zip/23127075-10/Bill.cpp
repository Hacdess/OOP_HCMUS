#include "Bill.h"

Bill::Bill()
{
    hasVAT = 0;
    id = "";
    clientName = "";
}

Bill::~Bill()
{
    hasVAT = 0;
    VAT = 0;
    id = "";
    clientName = "";
    products.clear();
}

void Bill::input()
{
    cout << "Enter bill's ID: ";
    cin.ignore();
    getline(cin, id);

    cout << "Enter client's name: ";
    getline(cin, clientName);

    cout << "Enter bills's type (1 if there is VAT, else 0): ";
    cin >> hasVAT;

    if (hasVAT)
    {
        do
        {
            cout << "Enter VAT (a positive integer, unit: %): ";
            cin >> VAT;
        } while (VAT <= 0);
    }
    else
        VAT = 0;

    int number;
    cout << "Input number of products to add to bill: ";
    cin >> number;

    for (int i = 0; i < number; ++i)
    {
        Product product;
        product.input();
        products.push_back(product);
        cout << endl;
    }
}

void Bill::output()
{
    cout << "=====================================================================\n";
    cout << "Bill's ID: " << id << endl;
    cout << "Client's name: " << clientName << endl;
    cout << "Bill's type: ";
    if (hasVAT)
        cout << "increasing-value bill - VAT: " << VAT << "%\n";
    else 
        cout << "single bill" << endl;

    cout << "---------------------------------------------------------------------\n";
    int len = products.size();
    cout << "Products:\n";
    for (int i = 0; i < len; ++i)
        products[i].output();
    cout << "=====================================================================\n\n";
}

bool Bill::checkVAT()
{
    return hasVAT;
}

string Bill::getClientName()
{
    return clientName;
}

double Bill::getTotalPrice()
{
    double price = 0;
    int len = products.size();

    for (int i = 0; i < len; ++i)
        price += products[i].getPrice();

    if (hasVAT)
        price = price * (1 + double(VAT) / 100);

    return price;
}
