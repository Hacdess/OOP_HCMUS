#include "Company.h"

Company::~Company()
{
    bills.clear();
}

void Company::input()
{
    int number;
    cout << "Input number of bills to input: ";
    cin >> number;
    cout << "Input Company's bills:\n\n";

    for (int i = 0; i < number; ++i)
    {
        Bill bill;
        bill.input();
        bills.push_back(bill);
    }
}

void Company::output()
{
    cout << "##### Company's bills #####\n";
    int len = bills.size();
    for (int i = 0; i < len; ++i)
        bills[i].output();
}

int Company::countHasVATBills()
{
    int count = 0;

    int len = bills.size();
    for (int i = 0; i < len; ++i)
        if (bills[i].checkVAT())
            ++count;

    return count;
}

void Company::outputByName(string name)
{
    int len = bills.size();
    for (int i = 0; i < len; ++i)
        if (name == bills[i].getClientName())
        {
            bills[i].output();
            cout << endl;
        }
}

void Company::swapBills(Bill &bill1, Bill &bill2)
{
    Bill temp = bill1;
    bill1 = bill2;
    bill2 = temp;
}

void Company::sortDescending()
{
    const double epsilon = 1e9;

    int len = bills.size();

    bool swapped;

    for (int i = 0; i < len - 1; ++i)
    {
        swapped = false;
        for (int j = i; j < len - 1; ++j)
        {
            if (bills[j].getTotalPrice() < bills[j + 1].getTotalPrice() ||
                bills[j].getTotalPrice() == bills[j + 1].getTotalPrice() &&
                strcmp(bills[j].getClientName().c_str(), bills[j + 1].getClientName().c_str()) > 0)
            {
                swap(bills[j], bills[j + 1]);
                swapped = true;
            }  
        }

        if (!swapped)
            break;
    }


}

double Company::getTotalRevenue()
{
    double revenue = 0;
    int len = bills.size();

    for (int i = 0; i < len; ++i)
        revenue += bills[i].getTotalPrice();

    return revenue;
}
