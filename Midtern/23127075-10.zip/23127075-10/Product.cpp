#include "Product.h"

Product::Product()
{
    name = "";
    price = 0;
}

void Product::input()
{
    cout << "Enter product's name: ";
    cin.ignore();
    getline(cin, name);

    do
    {
        cout << "Enter product's cost (non-negative real number): ";
        cin >> price;
    } while (price < 0);
}

void Product::output()
{
    cout << "Product: " << name << " - " << "Price: " << price << endl;
}

void Product::setName(string name)
{
    this->name = name;
}

void Product::setPrice(int price)
{
    this->price = price;
}

string Product::getName()
{
    return name;
}

    double Product::getPrice()
    {
        return price;
}
