#include "Company.h"

int main()
{
    cout << "Ex06: Building main\n\n";

    cout << "Ex01:\n";
    Company company;
    company.input();
    company.output();
    cout << endl;

    cout << "Ex02:\n";
    cout << "Number of increasing-value bills: " << company.countHasVATBills() << "\n\n";

    cout << "Ex03:\n";
    string name;
    cout << "Input client X's name: ";
    cin.ignore();
    getline(cin, name);
    cout << "All bills contains client " << name << ":\n\n";
    company.outputByName(name);
    cout << endl;

    cout << "Ex04:\n";
    company.sortDescending();
    cout << "Bills sorted descending!\n\n";
    company.output();
    cout << endl;

    cout << "Ex05:\n";
    cout << "Company's total revenue: " << company.getTotalRevenue();

    return 0;
}