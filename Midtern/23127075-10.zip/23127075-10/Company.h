#ifndef _COMPANY_H_
#define _COMPANY_H_

#include "Bill.h"
#include <cstring>
#include <cmath>

class Company
{
private:
    vector<Bill> bills;
public:
    ~Company();

    void input();
    void output();

    int countHasVATBills(); // Dem so luong don gia tri gia tang
    void outputByName(string name);
    void swapBills(Bill& bill1, Bill& bill2);
    void sortDescending();
    double getTotalRevenue();
};


#endif