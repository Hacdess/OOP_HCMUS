#ifndef _PRODUCT_H_
#define _PRODUCT_H_

#include <iostream>
#include <string>
using namespace std;

class Product
{
private:
    string name;
    double price;

public:
    Product();

    void input();
    void output();

    void setName(string name);
    void setPrice(int price);
    string getName();
    double getPrice();
};



#endif